#!/bin/sh

bin/busybox sh
